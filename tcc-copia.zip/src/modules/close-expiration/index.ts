import { routes } from './routes'
import { defineComponent } from 'vue'

export default defineComponent([routes])
