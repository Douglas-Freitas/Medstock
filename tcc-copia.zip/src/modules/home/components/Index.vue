<template>
  <v-container>
    <v-row>
      <v-col>
        <span>Seja bem-vindo ao MedStock</span>
      </v-col>
    </v-row>
  </v-container>
</template>
