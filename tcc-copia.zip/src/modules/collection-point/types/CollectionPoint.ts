export default interface CollectionPoint {
  name: string,
  id: string
}
