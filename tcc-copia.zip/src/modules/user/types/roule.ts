export default interface Roule {
  id: string
  name: string
}
