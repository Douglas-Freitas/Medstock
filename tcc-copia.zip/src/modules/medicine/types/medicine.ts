export default interface Medicine {
  id: string
  name: string
  validity: string
  quantity: string
  activePrinciple: string
}
